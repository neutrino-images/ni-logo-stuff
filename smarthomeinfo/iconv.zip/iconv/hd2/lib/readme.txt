
libiconv.so.2.5.1 nach /lib kopieren und Rechte 755 geben!

Dann per Telnet folgende Befehle ausf�hren:

ln -s /lib/libiconv.so.2.5.1 /lib/libiconv.so
ln -s /lib/libiconv.so.2.5.1 /lib/libiconv.so.2
