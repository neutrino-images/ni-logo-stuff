
libiconv.so.2.6.0 nach /lib kopieren und Rechte 755 geben!

Dann per Telnet folgende Befehle ausf�hren:

ln -s /lib/libiconv.so.2.6.0 /lib/libiconv.so
ln -s /lib/libiconv.so.2.6.0 /lib/libiconv.so.2


ACHTUNG:
F�r Nevis/HD1 empfiehlt sich wegen der Gr��e das Auslagern der iconv, libs und xmllint auf USB-Stick (alternativ Festplatte)
Also die Dateien: iconv, libiconv.so.2.6.0 und die xmllint auf den Stick/Festplatte in einen Ordner tools packen und Rechte 755 geben.

dann am einfachsten per Console die Symlinks anlegen, Beispiel:

ln -s  /media/USB-Stick-Name/tools/libiconv.so.2.6.0 /lib/libiconv.so.2.6.0
ln -s  /media/USB-Stick-Name/tools/libiconv.so.2.6.0 /lib/libiconv.so
ln -s  /media/USB-Stick-Name/tools/libiconv.so.2.6.0 /lib/libiconv.so.2
ln -s  /media/USB-Stick-Name/tools/iconv /bin/iconv
ln -s  /media/USB-Stick-Name/tools/xmllint /bin/xmllint

